#include <stdio.h>
#include <stdlib.h> //
#include <omp.h>

int main(int argc, char const *argv[]){
    int NUMS, NUMT;
    
    for (NUMS = 1024; NUMS <= 1024 * 1024 * 16; NUMS  *= 4) {
        float A[NUMS], B[NUMS], C[NUMS];
        
        for (NUMT = 1; NUMT <= 16; NUMT *= 2) {
            omp_set_num_threads( NUMT );
            double time0 = omp_get_wtime();  //time started

        #pragma omp parallel for default(none), shared(A, B, C)
            for( long int i = 0; i < NUMS; i++ )
            {
                C[i] = A[i]*B[i];
            }
            
            double time1 = omp_get_wtime();  //time ended

            double runTime = (time1 - time0) * 1000000.;
            printf("%10.2f\n", (float)(NUMS / (runTime)));
        }
    }
            return 0;
}